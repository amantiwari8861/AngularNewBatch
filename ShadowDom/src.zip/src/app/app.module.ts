import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ChildcompComponent } from './childtoparent/childcomp/childcomp.component';
import { ChildtoparentComponent } from './childtoparent/childtoparent.component';

@NgModule({
  declarations: [
    AppComponent,
    ChildtoparentComponent,
    ChildcompComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
