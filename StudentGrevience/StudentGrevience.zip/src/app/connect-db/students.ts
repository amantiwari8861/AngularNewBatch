export class student
{
    id !:number
    name !:string
    email !:string
}