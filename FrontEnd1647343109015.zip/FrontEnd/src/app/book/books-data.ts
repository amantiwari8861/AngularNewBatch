import { Book } from './book';
export var BOOKS: Book[] = [
    { "id": 1, "name": "HTML 5" },
    { "id": 2, "name": "CSS 3" },
    { "id": 3, "name": "Java Script" },
    { "id": 4, "name": "Ajax Programming" },
    { "id": 5, "name": "jQuery" },
    { "id": 6, "name": "Mastering Node.js" },
    { "id": 7, "name": "Angular JS 1.x" },
    { "id": 8, "name": "ng-book 2" },
    { "id": 9, "name": "Backbone JS" },
    { "id": 10, "name": "Yeoman" }
];
